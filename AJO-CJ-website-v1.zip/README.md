# AJO'CJ Website — First Working Version

This is a responsive static website for AJO'CJ.

## Files
- index.html — homepage
- styles.css — design and responsive layout
- script.js — mobile menu and basic search interaction

## Important
The stories currently shown are DEMO/PLACEHOLDER content. Replace them with verified stories before publishing. Do not present sample headlines as real news.

## Next production steps
1. Buy/register the preferred domain.
2. Put these files on a web host.
3. Connect the domain to the host and enable HTTPS.
4. Add real article pages and a CMS (WordPress or another publishing system) so new stories can be posted without editing HTML.
5. Add About, Contact, Privacy Policy, Terms and Editorial Policy.
6. Set up Google Search Console and an analytics system.
7. Build a consistent editorial workflow and then apply for an appropriate advertising/monetization program when eligible.
